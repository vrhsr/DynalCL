"""Stage 0.6 freeze steps (order: finalize code -> full validation -> validation report -> manifest -> manifest hash).

    python scripts/stage06_freeze.py record-tested     # before the final validation: hashes of every code/test/config file
    python scripts/stage06_freeze.py verify-tested     # after it: the same files are unchanged (marks the record verified)
    python scripts/stage06_freeze.py freeze            # environment manifest, freeze manifest, read-only snapshot

``freeze`` refuses unless the tested-file record is verified and every tested file still has its tested hash; the manifest
therefore contains exactly the hashes that were validated. It prints the manifest SHA-256 (store it OUTSIDE the
workspace) and the snapshot SHA-256.
"""

from __future__ import annotations

import datetime as _dt
import json
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

from dynaicl.config.stage06_schema import load_stage06_config  # noqa: E402
from dynaicl.experiments import stage06_freeze as F  # noqa: E402

TESTED = ROOT / "docs" / "STAGE06_TESTED_FILES.json"
MANIFEST_REL = "docs/FREEZE_MANIFEST_STAGE06.json"
SNAPSHOT = ROOT / "dist" / "stage06_frozen_snapshot.zip"


def now() -> str:
    return _dt.datetime.now(_dt.timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")


def main() -> int:
    cmd = sys.argv[1] if len(sys.argv) > 1 else ""
    if cmd == "record-tested":
        rec = {"recorded_utc": now(), "files": F.tested_file_hashes(ROOT), "verified_after_validation": False}
        TESTED.write_text(json.dumps(rec, indent=1, sort_keys=True) + "\n", encoding="utf-8", newline="\n")
        print(f"recorded {len(rec['files'])} tested files -> {TESTED}")
        return 0
    if cmd == "verify-tested":
        rec = json.loads(TESTED.read_text(encoding="utf-8"))
        cur = F.tested_file_hashes(ROOT)
        diff = sorted(set(cur) ^ set(rec["files"])) + sorted(k for k in cur if k in rec["files"] and cur[k] != rec["files"][k])
        if diff:
            print(f"CHANGED since the record: {diff}")
            return 1
        rec.update({"verified_after_validation": True, "verified_utc": now()})
        TESTED.write_text(json.dumps(rec, indent=1, sort_keys=True) + "\n", encoding="utf-8", newline="\n")
        print(f"verified: {len(cur)} tested files unchanged since {rec['recorded_utc']}")
        return 0
    if cmd == "freeze":
        rec = json.loads(TESTED.read_text(encoding="utf-8"))
        if not rec.get("verified_after_validation"):
            print("refused: the tested-file record was not verified after the final validation")
            return 1
        cur = F.tested_file_hashes(ROOT)
        if cur != rec["files"]:
            print("refused: code/test/config files differ from the validated hashes")
            return 1
        F.write_environment_manifest(ROOT)
        stage05 = load_stage06_config(ROOT / "config" / "stage06.yaml").tier2.stage05_run
        manifest = F.build_manifest(ROOT, stage05)
        mismatch = [k for k, v in rec["files"].items() if manifest["files"].get(k) != v]
        if mismatch:
            print(f"refused: manifest hashes differ from the tested hashes: {mismatch}")
            return 1
        path, sha = F.write_manifest(ROOT, manifest, MANIFEST_REL)
        snap_sha = F.write_snapshot(ROOT, manifest, MANIFEST_REL, SNAPSHOT)
        (ROOT / "dist" / "stage06_frozen_snapshot.sha256").write_text(
            f"{snap_sha}  stage06_frozen_snapshot.zip\n{sha}  {MANIFEST_REL}\n", encoding="utf-8", newline="\n")
        print(f"files frozen: {len(manifest['files'])}")
        print(f"MANIFEST SHA-256: {sha}  ({MANIFEST_REL})")
        print(f"SNAPSHOT SHA-256: {snap_sha}  ({SNAPSHOT.relative_to(ROOT)})")
        for c, v in manifest["config_hashes"].items():
            print(f"config {c}: {v['mode']} {v['config_hash']}")
        return 0
    print(__doc__)
    return 2


if __name__ == "__main__":
    raise SystemExit(main())
